class AppImagesConfig {
  static const String noImageUrl =
      'https://newspro.uixxy.com/wp-content/uploads/2022/08/newspro_default_image.png';

  static String defaultCategoryImage =
      'https://newspro.uixxy.com/wp-content/uploads/2022/08/newspro_default_category.png';
}
