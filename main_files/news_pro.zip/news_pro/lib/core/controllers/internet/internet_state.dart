enum InternetState { loading, connected, disconnected }
