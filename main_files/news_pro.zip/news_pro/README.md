
# NewsPro
NewsPro is an awesome news app that uses your existing WordPress admin panel and creates native Android and iOS apps in minutes. Convert any WordPress-based website into a native android and ios news app. Just put your website link and simply configure your website, and it will be all yours.


![Logo](./assets/others/logo.png)


## Authors

- [@abdulmominsakib](https://www.github.com/abdulmominsakib)


## Features

![image1](https://i.imgur.com/MR7hJ5P.png)
![image2](https://i.imgur.com/zA6YG0i.png)
![image3](https://i.imgur.com/cRD7AxO.png)
![image4](https://i.imgur.com/Gmlpeuk.png)
![image5](https://i.imgur.com/AGluAXs.png)
![image6](https://i.imgur.com/TJ9itYb.png)
![testomonials](https://i.imgur.com/HCdLK0P.png)
![download](https://i.imgur.com/6pqLJHP.png)
[Get it on Google Play]((https://play.google.com/store/apps/details?id=com.abdulmomin.newspro&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1))


## Tech Stack

**Client:** Flutter

**Server:** PHP, WordPress

